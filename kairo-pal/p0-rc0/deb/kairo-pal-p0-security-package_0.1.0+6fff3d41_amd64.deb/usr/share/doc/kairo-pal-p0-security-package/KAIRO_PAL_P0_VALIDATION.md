# KAIRO PAL P0 Validation

## Coverage

- PAL Windows AD / Netlogon boundary gate added in `kairo-sec`.
- MCP Toolbox CORS/SSE boundary gate added in `kairo-sec`.
- Credential theft egress and webhook exfiltration boundary gate added in `kairo-sec`.
- Developer extension update supply-chain poisoning gate added in `kairo-sec`.
- Agent API taint git control gate added in `kairo-sec`.
- Rule metadata added in the non-CVE response matrix and Windows rulepack.
- Integration tests cover:
  - NotApplicable on non-Windows / non-AD findings
  - Clean on ordinary non-DC Windows event metadata
  - Quarantine on suspicious Netlogon / secure-channel anomaly with incomplete identity
  - FailClosed on Domain Controller emergency indicators
  - Missing identity not silently allowing suspicious DC-critical signals
  - `ObserveUnknownIdentity` is observation-only when evidence is incomplete, not an affirmative trust decision
  - Metadata-only credential theft egress evaluation for benign egress, webhook exfiltration, credential access, persistence, and incomplete high-risk cases
  - Metadata-only developer extension update evaluation for clean manual updates, source drift, privileged auto-update risk, credential-surface access, outbound egress, and incomplete high-risk cases
  - Metadata-only agent API taint evaluation for tainted merge/push/pull, tainted reset/clean/restore/checkout --force, read-only git metadata, approval-bypass audit visibility, and incomplete high-risk cases

## Validation Commands

- `cargo fmt --check`
- `CARGO_TARGET_DIR=/tmp/tuff-kairo-target cargo check -p kairo-sec`
- `CARGO_TARGET_DIR=/tmp/tuff-kairo-target cargo test -p kairo-sec --test agent_api_taint`
- `CARGO_TARGET_DIR=/tmp/tuff-kairo-target cargo test -p kairo-sec --test developer_extension_update`
- `CARGO_TARGET_DIR=/tmp/tuff-kairo-target cargo test -p kairo-sec --test pal_netlogon_boundary`
- `CARGO_TARGET_DIR=/tmp/tuff-kairo-target cargo test -p kairo-sec --test rule_metadata_consistency`
- `git diff --check`

## Known Full-Test Blocker

- `vulkan_gpu::tests::prefilter_invokes_tuff_gpgpu_and_returns_result`
- Failure mode: SIGSEGV
- Status: pre-existing blocker outside this PAL P0 task

## Scope Reminder

- No exploit reproduction.
- No live Netlogon / RPC / LDAP / SMB probing.
- No live AI API probing.
- No API key access.
- No TLS inspection.
- No real stdin/stdout/stderr capture.
- No GUI popup or password broker implementation.
- No password storage.
- No process kill.
- No OS sandbox enforcement.
- No registry mutation.
- No firewall mutation.
- No editor settings mutation.
- No system configuration mutation.
