# PAL Regular Route Risk Boundary

## Definition

This boundary class covers "regular-route" security holes: trusted product workflows that legitimately execute attacker-influenced material across a trust boundary.

The problem is not authentication bypass in the narrow sense. The problem is that a nominally trusted workflow can become a remote execution, pivot, or trust-boundary escalation path when its integrity checks are weak.

## Examples

- VS Code Remote-SSH bootstrap scripts generated on a developer endpoint and transferred to a remote host.
- Browser sync vault device-join flows that should not be treated as a root of trust.
- MCP and agent tool ingress where ordinary product behavior can carry untrusted content into execution.
- Developer endpoint to cloud/server bootstrap paths that legitimately cross from local context to remote execution.

## PAL Response Mapping

- `observe`: record the path, keep evidence, and do not elevate it into execution.
- `quarantine`: constrain the trust boundary and require additional checks.
- `fail_closed`: block the path when integrity or scope is not sufficient.
- `no_response_preferred`: where a silent outcome is operationally safer than a visible oracle, prefer silence over a detailed rejection.

## Operating Rule

PAL does not patch vendor products. PAL detects and constrains trust-boundary execution, then hands a verdict to KAIRO or the downstream package layer.
